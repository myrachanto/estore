@extends('master')
@section('header1')
    <meta name="description" content="erp" />
	<title>chantosweb erp</title>
    
@endsection

@section('content')
<br /><br />
<div id="about" class="container-fluid carodiv">

    <div class="col-sm-8">
      <h1 class="specialh">Why us</h1><br>
      <h3>We provide the best responsive e commerce website solutions to our clients.</h3><br>
      <p>
Chantosweb developers is a firm that offers solution to web development needs that has arose from the alarming growth rate of e commerce websites. Our websites range from simple sites to sophisticated web application such as E.R.Ps. Our e commerce sites examples are hosted in our sub domains to provide testing grounds to evaluate their proficiency.<br /> We have embraced the latest technology to bring forth responsive, efficient, effective, best e commerce websites on the globe. Our work can be best described as an art in the world of artisans.</p>

    </div>
    <div class="col-sm-4">
      
      <img src="{{asset('img/no3.jpg')}}" class="img-responsive img-circle imgstyle" alt="chantosweb developers" />
    </div>
  
</div>

@endsection