@extends('master')
@section('header1')
    <meta name="description" content="erp" />
	<title>chantosweb erp</title>
    
@endsection

@section('content')
<br /><br />
<div id="about" class="container-fluid carodiv">

    <div class="col-sm-6 "><br />
      <h1 class="specialh">Chantosweb Developers you dream we make it a reality</h1>
    <p>for more infortion call +254729308456</p>
    <p>Or email info@chantosweb.com</p>
    <p>to get to see what we offer visit <a href="http://www.chantosweb.com">www.chantosweb.com</a>
    </div>
    <div class="col-sm-6">
      
      <img src="{{asset('img/no3.jpg')}}" class="img-responsive img-circle imgstyle" alt="chantosweb developers" />
    </div>
  
</div>

@endsection